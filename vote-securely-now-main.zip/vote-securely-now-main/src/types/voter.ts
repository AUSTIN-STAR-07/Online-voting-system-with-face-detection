export interface Voter {
  id: string;
  name: string;
  email: string;
  voterId: string;
  dateOfBirth: string;
  age: number;
  photo: string;
  gender: 'male' | 'female' | 'other';
  addressProof: string;
  registeredAt: string;
  hasVoted: boolean;
  votedParty?: string;
  votedAt?: string;
}

export interface PoliticalParty {
  id: string;
  name: string;
  abbreviation: string;
  category: 'national' | 'state';
  state?: string;
  color: string;
  votes: number;
  symbol?: string;
}

export interface VoteRecord {
  voterId: string;
  partyId: string;
  timestamp: string;
}

export interface FeedbackRecord {
  id: string;
  name: string;
  email: string;
  category: string;
  rating: string;
  message: string;
  submittedAt: string;
}

import { PoliticalParty } from '@/types/voter';

export const politicalParties: PoliticalParty[] = [
  // 🏛️ National Political Parties (Major)
  { id: 'bjp', name: 'Bharatiya Janata Party', abbreviation: 'BJP', category: 'national', color: '#FF9933', votes: 0, symbol: '🪷' },
  { id: 'inc', name: 'Indian National Congress', abbreviation: 'INC', category: 'national', color: '#00BFFF', votes: 0, symbol: '✋' },
  { id: 'bsp', name: 'Bahujan Samaj Party', abbreviation: 'BSP', category: 'national', color: '#2196F3', votes: 0, symbol: '🐘' },
  { id: 'aap', name: 'Aam Aadmi Party', abbreviation: 'AAP', category: 'national', color: '#00BCD4', votes: 0, symbol: '🧹' },
  { id: 'cpim', name: 'Communist Party of India (Marxist)', abbreviation: 'CPI(M)', category: 'national', color: '#F44336', votes: 0, symbol: '⚒️' },
  { id: 'cpi', name: 'Communist Party of India', abbreviation: 'CPI', category: 'national', color: '#E53935', votes: 0, symbol: '🌾' },
  { id: 'npp', name: "National People's Party", abbreviation: 'NPP', category: 'national', color: '#9C27B0', votes: 0, symbol: '📖' },

  // 🏛️ Major State & Regional Political Parties

  // Tamil Nadu
  { id: 'dmk', name: 'Dravida Munnetra Kazhagam', abbreviation: 'DMK', category: 'state', state: 'Tamil Nadu', color: '#D32F2F', votes: 0, symbol: '☀️' },
  { id: 'aiadmk', name: 'All India Anna Dravida Munnetra Kazhagam', abbreviation: 'AIADMK', category: 'state', state: 'Tamil Nadu', color: '#388E3C', votes: 0, symbol: '🍃' },
  { id: 'tvk', name: 'Tamilaga Vettri Kazhagam', abbreviation: 'TVK', category: 'state', state: 'Tamil Nadu', color: '#FFC107', votes: 0, symbol: '⭐' },
  { id: 'vck', name: 'Viduthalai Chiruthaigal Katchi', abbreviation: 'VCK', category: 'state', state: 'Tamil Nadu', color: '#3F51B5', votes: 0, symbol: '🔔' },
  { id: 'ammk', name: 'Amma Makkal Munnetra Kazhagam', abbreviation: 'AMMK', category: 'state', state: 'Tamil Nadu', color: '#009688', votes: 0, symbol: '🎯' },
  { id: 'pmk', name: 'Pattali Makkal Katchi', abbreviation: 'PMK', category: 'state', state: 'Tamil Nadu', color: '#795548', votes: 0, symbol: '🥭' },
  { id: 'dmdk', name: 'Desiya Murpokku Dravida Kazhagam', abbreviation: 'DMDK', category: 'state', state: 'Tamil Nadu', color: '#607D8B', votes: 0, symbol: '🎬' },

  // Telangana & Andhra Pradesh
  { id: 'brs', name: 'Bharat Rashtra Samithi', abbreviation: 'BRS', category: 'state', state: 'Telangana', color: '#E91E63', votes: 0, symbol: '🚗' },
  { id: 'tdp', name: 'Telugu Desam Party', abbreviation: 'TDP', category: 'state', state: 'Andhra Pradesh', color: '#FFEB3B', votes: 0, symbol: '🚲' },
  { id: 'ysrcp', name: 'Yuvajana Sramika Rythu Congress Party', abbreviation: 'YSRCP', category: 'state', state: 'Andhra Pradesh', color: '#4CAF50', votes: 0, symbol: '⏰' },

  // West Bengal
  { id: 'tmc', name: 'All India Trinamool Congress', abbreviation: 'AITC/TMC', category: 'state', state: 'West Bengal', color: '#03A9F4', votes: 0, symbol: '🌸' },

  // Uttar Pradesh
  { id: 'sp', name: 'Samajwadi Party', abbreviation: 'SP', category: 'state', state: 'Uttar Pradesh', color: '#F44336', votes: 0, symbol: '🚲' },
  { id: 'rld', name: 'Rashtriya Lok Dal', abbreviation: 'RLD', category: 'state', state: 'Uttar Pradesh', color: '#4CAF50', votes: 0, symbol: '🧑‍🌾' },

  // Bihar
  { id: 'jdu', name: 'Janata Dal (United)', abbreviation: 'JD(U)', category: 'state', state: 'Bihar', color: '#2196F3', votes: 0, symbol: '🏹' },
  { id: 'rjd', name: 'Rashtriya Janata Dal', abbreviation: 'RJD', category: 'state', state: 'Bihar', color: '#4CAF50', votes: 0, symbol: '🏮' },
  { id: 'ljp', name: 'Lok Janshakti Party', abbreviation: 'LJP', category: 'state', state: 'Bihar', color: '#FF5722', votes: 0, symbol: '🏠' },

  // Maharashtra
  { id: 'ss', name: 'Shiv Sena', abbreviation: 'SS', category: 'state', state: 'Maharashtra', color: '#FF9800', votes: 0, symbol: '🏹' },
  { id: 'ncp', name: 'Nationalist Congress Party', abbreviation: 'NCP', category: 'state', state: 'Maharashtra', color: '#00BCD4', votes: 0, symbol: '⏰' },
  { id: 'mns', name: 'Maharashtra Navnirman Sena', abbreviation: 'MNS', category: 'state', state: 'Maharashtra', color: '#FF5722', votes: 0, symbol: '🚂' },

  // Punjab
  { id: 'sad', name: 'Shiromani Akali Dal', abbreviation: 'SAD', category: 'state', state: 'Punjab', color: '#3F51B5', votes: 0, symbol: '⚖️' },

  // Odisha
  { id: 'bjd', name: 'Biju Janata Dal', abbreviation: 'BJD', category: 'state', state: 'Odisha', color: '#4CAF50', votes: 0, symbol: '🐚' },

  // Jammu & Kashmir
  { id: 'nc', name: 'National Conference', abbreviation: 'NC', category: 'state', state: 'Jammu & Kashmir', color: '#F44336', votes: 0, symbol: '🌿' },
  { id: 'pdp', name: "People's Democratic Party", abbreviation: 'PDP', category: 'state', state: 'Jammu & Kashmir', color: '#4CAF50', votes: 0, symbol: '✏️' },

  // 🗳️ Others
  { id: 'iuml', name: 'Indian Union Muslim League', abbreviation: 'IUML', category: 'state', state: 'Kerala', color: '#4CAF50', votes: 0, symbol: '🏠' },
  { id: 'jmm', name: 'Jharkhand Mukti Morcha', abbreviation: 'JMM', category: 'state', state: 'Jharkhand', color: '#009688', votes: 0, symbol: '🏹' },
  { id: 'agp', name: 'Asom Gana Parishad', abbreviation: 'AGP', category: 'state', state: 'Assam', color: '#FF9800', votes: 0, symbol: '🐘' },
];

export const getPartyById = (id: string): PoliticalParty | undefined => {
  return politicalParties.find(party => party.id === id);
};

export const getNationalParties = (): PoliticalParty[] => {
  return politicalParties.filter(party => party.category === 'national');
};

export const getStateParties = (): PoliticalParty[] => {
  return politicalParties.filter(party => party.category === 'state');
};

export const getPartiesByState = (state: string): PoliticalParty[] => {
  return politicalParties.filter(party => party.state === state);
};

import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useVoting } from '@/context/VotingContext';
import { Vote, Home, Info, MessageSquare, Shield, LogOut, User } from 'lucide-react';

const Navbar: React.FC = () => {
  const location = useLocation();
  const { isLoggedIn, isAdmin, currentVoter, logout } = useVoting();

  const isActive = (path: string) => location.pathname === path;

  const navLinks = [
    { path: '/', label: 'Home', icon: Home },
    { path: '/about', label: 'About', icon: Info },
    { path: '/vote', label: 'Post Your Vote', icon: Vote, requiresAuth: true },
    { path: '/admin', label: 'Admin', icon: Shield },
    { path: '/feedback', label: 'Feedback', icon: MessageSquare },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full glass-effect border-b border-border/50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg saffron-gradient flex items-center justify-center">
              <Vote className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-secondary">
              e<span className="text-primary">Vote</span> India
            </span>
          </Link>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => {
              if (link.requiresAuth && !isLoggedIn) return null;
              const Icon = link.icon;
              return (
                <Link key={link.path} to={link.path}>
                  <Button
                    variant={isActive(link.path) ? "default" : "ghost"}
                    size="sm"
                    className={`gap-2 ${isActive(link.path) ? 'saffron-gradient' : ''}`}
                  >
                    <Icon className="w-4 h-4" />
                    {link.label}
                  </Button>
                </Link>
              );
            })}
          </div>

          {/* Auth Buttons */}
          <div className="flex items-center gap-2">
            {isLoggedIn ? (
              <div className="flex items-center gap-3">
                {currentVoter && (
                  <div className="hidden sm:flex items-center gap-2 text-sm">
                    <User className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">{currentVoter.name}</span>
                  </div>
                )}
                {isAdmin && (
                  <span className="px-2 py-1 bg-secondary text-secondary-foreground text-xs rounded-full font-medium">
                    Admin
                  </span>
                )}
                <Button variant="outline" size="sm" onClick={logout} className="gap-2">
                  <LogOut className="w-4 h-4" />
                  Logout
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link to="/login">
                  <Button variant="ghost" size="sm">Login</Button>
                </Link>
                <Link to="/register">
                  <Button size="sm" className="saffron-gradient">Register</Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="md:hidden border-t border-border/50 bg-background/95 backdrop-blur-sm">
        <div className="flex justify-around py-2">
          {navLinks.slice(0, 4).map((link) => {
            if (link.requiresAuth && !isLoggedIn) return null;
            const Icon = link.icon;
            return (
              <Link key={link.path} to={link.path}>
                <Button
                  variant="ghost"
                  size="sm"
                  className={`flex-col h-auto py-2 px-3 ${isActive(link.path) ? 'text-primary' : 'text-muted-foreground'}`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-xs mt-1">{link.label}</span>
                </Button>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

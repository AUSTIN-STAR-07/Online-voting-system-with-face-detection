import React, { useRef, useState, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Camera, CheckCircle, XCircle, RefreshCw, Loader2 } from 'lucide-react';
import { useVoting } from '@/context/VotingContext';

interface FaceVerificationProps {
  onVerificationComplete: (success: boolean) => void;
}

const FaceVerification: React.FC<FaceVerificationProps> = ({ onVerificationComplete }) => {
  const { currentVoter } = useVoting();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const registeredCanvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<'success' | 'failed' | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [similarityScore, setSimilarityScore] = useState<number | null>(null);

  const startCamera = useCallback(async () => {
    try {
      setCameraError(null);
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: 640, height: 480 }
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      setCameraError('Unable to access camera. Please ensure camera permissions are granted.');
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  }, [stream]);

  useEffect(() => {
    startCamera();
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        const imageData = canvas.toDataURL('image/jpeg');
        setCapturedImage(imageData);
        stopCamera();
      }
    }
  };

  const retakePhoto = () => {
    setCapturedImage(null);
    setVerificationResult(null);
    setSimilarityScore(null);
    startCamera();
  };

  // Real image comparison using pixel analysis
  const compareImages = async (capturedImg: string, registeredImg: string): Promise<number> => {
    return new Promise((resolve) => {
      const img1 = new Image();
      const img2 = new Image();
      
      let loadedCount = 0;
      
      const onBothLoaded = () => {
        loadedCount++;
        if (loadedCount < 2) return;
        
        const canvas1 = document.createElement('canvas');
        const canvas2 = document.createElement('canvas');
        const size = 100; // Normalize to 100x100 for comparison
        
        canvas1.width = size;
        canvas1.height = size;
        canvas2.width = size;
        canvas2.height = size;
        
        const ctx1 = canvas1.getContext('2d');
        const ctx2 = canvas2.getContext('2d');
        
        if (!ctx1 || !ctx2) {
          resolve(0);
          return;
        }
        
        // Draw both images to same size
        ctx1.drawImage(img1, 0, 0, size, size);
        ctx2.drawImage(img2, 0, 0, size, size);
        
        // Get pixel data
        const data1 = ctx1.getImageData(0, 0, size, size).data;
        const data2 = ctx2.getImageData(0, 0, size, size).data;
        
        // Calculate histogram similarity for better comparison
        const histogram1 = calculateHistogram(data1);
        const histogram2 = calculateHistogram(data2);
        
        // Compare histograms using correlation
        const similarity = compareHistograms(histogram1, histogram2);
        
        resolve(similarity);
      };
      
      img1.onload = onBothLoaded;
      img2.onload = onBothLoaded;
      img1.onerror = () => resolve(0);
      img2.onerror = () => resolve(0);
      
      img1.src = capturedImg;
      img2.src = registeredImg;
    });
  };

  const calculateHistogram = (data: Uint8ClampedArray): number[] => {
    const histogram = new Array(256).fill(0);
    for (let i = 0; i < data.length; i += 4) {
      // Convert to grayscale
      const gray = Math.floor(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
      histogram[gray]++;
    }
    // Normalize
    const total = data.length / 4;
    return histogram.map(v => v / total);
  };

  const compareHistograms = (h1: number[], h2: number[]): number => {
    let sum1 = 0, sum2 = 0, sum12 = 0;
    let sq1 = 0, sq2 = 0;
    
    const mean1 = h1.reduce((a, b) => a + b, 0) / h1.length;
    const mean2 = h2.reduce((a, b) => a + b, 0) / h2.length;
    
    for (let i = 0; i < h1.length; i++) {
      const d1 = h1[i] - mean1;
      const d2 = h2[i] - mean2;
      sum12 += d1 * d2;
      sq1 += d1 * d1;
      sq2 += d2 * d2;
    }
    
    const denominator = Math.sqrt(sq1 * sq2);
    if (denominator === 0) return 0;
    
    // Correlation coefficient normalized to 0-100
    const correlation = (sum12 / denominator + 1) / 2 * 100;
    return correlation;
  };

  const verifyFace = async () => {
    if (!capturedImage || !currentVoter?.photo) {
      setVerificationResult('failed');
      return;
    }

    setIsVerifying(true);
    
    try {
      // Compare the captured image with the registered photo
      const similarity = await compareImages(capturedImage, currentVoter.photo);
      setSimilarityScore(Math.round(similarity));
      
      // Threshold for matching (adjustable - 60% similarity required)
      const isMatch = similarity >= 60;
      
      setVerificationResult(isMatch ? 'success' : 'failed');
      
      if (isMatch) {
        setTimeout(() => {
          onVerificationComplete(true);
        }, 2000);
      }
    } catch (error) {
      console.error('Verification error:', error);
      setVerificationResult('failed');
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="voting-card max-w-2xl mx-auto animate-fade-in">
      <div className="text-center mb-6">
        <div className="w-16 h-16 rounded-full saffron-gradient flex items-center justify-center mx-auto mb-4">
          <Camera className="w-8 h-8 text-primary-foreground" />
        </div>
        <h2 className="text-2xl font-bold text-foreground">Face Verification</h2>
        <p className="text-muted-foreground mt-2">
          Verify your identity by matching your face with the registered photo
        </p>
      </div>

      {/* Side by Side Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Registered Photo */}
        <div className="p-4 bg-muted/50 rounded-xl border-2 border-dashed border-primary/20">
          <p className="text-sm font-medium text-muted-foreground mb-3 text-center">📷 Registered Photo</p>
          {currentVoter?.photo ? (
            <div className="aspect-square max-w-[200px] mx-auto rounded-xl overflow-hidden border-4 border-primary/30 shadow-lg">
              <img 
                src={currentVoter.photo} 
                alt="Registered" 
                className="w-full h-full object-cover"
              />
            </div>
          ) : (
            <div className="aspect-square max-w-[200px] mx-auto rounded-xl bg-muted flex items-center justify-center">
              <p className="text-sm text-muted-foreground">No photo registered</p>
            </div>
          )}
          <p className="text-xs text-center text-muted-foreground mt-2">
            {currentVoter?.name}
          </p>
        </div>

        {/* Live Camera / Captured Photo */}
        <div className="p-4 bg-muted/50 rounded-xl border-2 border-dashed border-accent/20">
          <p className="text-sm font-medium text-muted-foreground mb-3 text-center">📹 Live Camera</p>
          <div className="aspect-square max-w-[200px] mx-auto rounded-xl overflow-hidden border-4 border-accent/30 shadow-lg relative">
            {cameraError ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-muted">
                <XCircle className="w-8 h-8 text-destructive mb-2" />
                <p className="text-xs text-destructive">{cameraError}</p>
              </div>
            ) : capturedImage ? (
              <img src={capturedImage} alt="Captured" className="w-full h-full object-cover" />
            ) : (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            )}
            <canvas ref={canvasRef} className="hidden" />

            {/* Verification Overlay */}
            {verificationResult && (
              <div className={`absolute inset-0 flex flex-col items-center justify-center ${
                verificationResult === 'success' ? 'bg-accent/90' : 'bg-destructive/90'
              }`}>
                {verificationResult === 'success' ? (
                  <>
                    <CheckCircle className="w-12 h-12 text-accent-foreground mb-2" />
                    <p className="text-sm font-bold text-accent-foreground">Matched!</p>
                  </>
                ) : (
                  <>
                    <XCircle className="w-12 h-12 text-destructive-foreground mb-2" />
                    <p className="text-sm font-bold text-destructive-foreground">No Match</p>
                  </>
                )}
              </div>
            )}
          </div>
          <p className="text-xs text-center text-muted-foreground mt-2">
            {capturedImage ? 'Captured photo' : 'Position your face'}
          </p>
        </div>
      </div>

      {/* Similarity Score */}
      {similarityScore !== null && (
        <div className={`text-center p-4 rounded-lg mb-6 ${
          verificationResult === 'success' ? 'bg-accent/10' : 'bg-destructive/10'
        }`}>
          <p className="text-sm text-muted-foreground">Similarity Score</p>
          <p className={`text-3xl font-bold ${
            verificationResult === 'success' ? 'text-accent' : 'text-destructive'
          }`}>
            {similarityScore}%
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            {verificationResult === 'success' 
              ? '✓ Face verification successful' 
              : '✗ Face does not match - Please try again'}
          </p>
        </div>
      )}

      {/* Result Message */}
      {verificationResult === 'success' && (
        <div className="bg-accent/10 border border-accent/30 rounded-lg p-4 mb-6 text-center">
          <CheckCircle className="w-8 h-8 text-accent mx-auto mb-2" />
          <p className="font-semibold text-accent">Face Matched Successfully!</p>
          <p className="text-sm text-muted-foreground">Proceeding to voting page...</p>
        </div>
      )}

      {verificationResult === 'failed' && (
        <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-4 mb-6 text-center">
          <XCircle className="w-8 h-8 text-destructive mx-auto mb-2" />
          <p className="font-semibold text-destructive">Face Does Not Match!</p>
          <p className="text-sm text-muted-foreground">The captured photo does not match your registered photo. Please try again.</p>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-3">
        {!capturedImage ? (
          <Button 
            onClick={capturePhoto} 
            className="flex-1 saffron-gradient"
            disabled={!stream}
          >
            <Camera className="w-4 h-4 mr-2" />
            Capture Photo
          </Button>
        ) : verificationResult === 'failed' ? (
          <Button onClick={retakePhoto} className="flex-1" variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Retake Photo
          </Button>
        ) : !verificationResult ? (
          <>
            <Button onClick={retakePhoto} variant="outline" className="flex-1">
              <RefreshCw className="w-4 h-4 mr-2" />
              Retake
            </Button>
            <Button 
              onClick={verifyFace} 
              className="flex-1 saffron-gradient"
              disabled={isVerifying}
            >
              {isVerifying ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Comparing...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Verify Face
                </>
              )}
            </Button>
          </>
        ) : null}
      </div>

      {/* Instructions */}
      <div className="mt-6 p-4 bg-muted/30 rounded-lg">
        <p className="text-xs text-muted-foreground text-center">
          💡 <strong>Tips:</strong> Ensure good lighting, look directly at the camera, and remove any face coverings for accurate verification.
        </p>
      </div>
    </div>
  );
};

export default FaceVerification;

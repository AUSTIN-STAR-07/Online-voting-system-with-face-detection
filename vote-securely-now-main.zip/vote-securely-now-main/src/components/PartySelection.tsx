import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { politicalParties, getNationalParties, getStateParties } from '@/data/politicalParties';
import { PoliticalParty } from '@/types/voter';
import { useVoting } from '@/context/VotingContext';
import { Vote, Check, AlertCircle } from 'lucide-react';

interface PartySelectionProps {
  onVoteComplete: () => void;
}

const PartySelection: React.FC<PartySelectionProps> = ({ onVoteComplete }) => {
  const { castVote } = useVoting();
  const [selectedParty, setSelectedParty] = useState<PoliticalParty | null>(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [voteSubmitted, setVoteSubmitted] = useState(false);

  const nationalParties = getNationalParties();
  const stateParties = getStateParties();

  // Group state parties by state
  const statePartiesGrouped = stateParties.reduce((acc, party) => {
    const state = party.state || 'Other';
    if (!acc[state]) acc[state] = [];
    acc[state].push(party);
    return acc;
  }, {} as Record<string, PoliticalParty[]>);

  const handlePartyClick = (party: PoliticalParty) => {
    setSelectedParty(party);
    setShowConfirmDialog(true);
  };

  const handleConfirmVote = () => {
    if (selectedParty) {
      const success = castVote(selectedParty.id);
      if (success) {
        setVoteSubmitted(true);
        setShowConfirmDialog(false);
        setTimeout(() => {
          onVoteComplete();
        }, 3000);
      }
    }
  };

  if (voteSubmitted) {
    return (
      <div className="voting-card max-w-lg mx-auto text-center animate-scale-in">
        <div className="w-20 h-20 rounded-full bg-accent flex items-center justify-center mx-auto mb-6">
          <Check className="w-10 h-10 text-accent-foreground" />
        </div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Vote Registered Successfully!</h2>
        <p className="text-muted-foreground mb-4">
          Your vote for <span className="font-semibold text-primary">{selectedParty?.name}</span> has been recorded.
        </p>
        <p className="text-sm text-muted-foreground">Thank you for participating in the democratic process.</p>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="text-center mb-8">
        <div className="w-16 h-16 rounded-full saffron-gradient flex items-center justify-center mx-auto mb-4">
          <Vote className="w-8 h-8 text-primary-foreground" />
        </div>
        <h2 className="text-2xl font-bold text-foreground">Select Your Party</h2>
        <p className="text-muted-foreground mt-2">Click on a party to cast your vote</p>
      </div>

      <Tabs defaultValue="national" className="w-full">
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-6">
          <TabsTrigger value="national">National Parties</TabsTrigger>
          <TabsTrigger value="state">State Parties</TabsTrigger>
        </TabsList>

        <TabsContent value="national">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {nationalParties.map((party) => (
              <button
                key={party.id}
                onClick={() => handlePartyClick(party)}
                className="party-card text-left p-5 transition-all hover:scale-[1.02]"
              >
                <div className="flex items-start gap-3">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold text-lg shrink-0"
                    style={{ backgroundColor: party.color }}
                  >
                    {party.abbreviation.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-semibold text-foreground truncate">{party.name}</h3>
                    <p className="text-sm text-muted-foreground">{party.abbreviation}</p>
                    <span className="inline-block mt-2 px-2 py-0.5 bg-primary/10 text-primary text-xs rounded-full">
                      National
                    </span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="state">
          <div className="space-y-8">
            {Object.entries(statePartiesGrouped).map(([state, parties]) => (
              <div key={state}>
                <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-primary"></span>
                  {state}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {parties.map((party) => (
                    <button
                      key={party.id}
                      onClick={() => handlePartyClick(party)}
                      className="party-card text-left p-5 transition-all hover:scale-[1.02]"
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold text-lg shrink-0"
                          style={{ backgroundColor: party.color }}
                        >
                          {party.abbreviation.charAt(0)}
                        </div>
                        <div className="min-w-0">
                          <h3 className="font-semibold text-foreground text-sm leading-tight">{party.name}</h3>
                          <p className="text-sm text-muted-foreground">{party.abbreviation}</p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Confirmation Dialog */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-primary" />
              Confirm Your Vote
            </DialogTitle>
            <DialogDescription>
              You are about to cast your vote for:
            </DialogDescription>
          </DialogHeader>
          
          {selectedParty && (
            <div className="py-4">
              <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
                <div
                  className="w-16 h-16 rounded-lg flex items-center justify-center text-white font-bold text-xl"
                  style={{ backgroundColor: selectedParty.color }}
                >
                  {selectedParty.abbreviation.charAt(0)}
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">{selectedParty.name}</h4>
                  <p className="text-sm text-muted-foreground">{selectedParty.abbreviation}</p>
                </div>
              </div>
              <p className="text-sm text-destructive mt-4 flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                This action cannot be undone. You can only vote once.
              </p>
            </div>
          )}

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setShowConfirmDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleConfirmVote} className="saffron-gradient">
              <Vote className="w-4 h-4 mr-2" />
              Confirm Vote
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PartySelection;

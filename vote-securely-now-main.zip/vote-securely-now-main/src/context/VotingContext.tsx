import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Voter, VoteRecord, FeedbackRecord } from '@/types/voter';
import { politicalParties } from '@/data/politicalParties';

interface VotingContextType {
  voters: Voter[];
  currentVoter: Voter | null;
  votes: VoteRecord[];
  partyVotes: Record<string, number>;
  feedbacks: FeedbackRecord[];
  isLoggedIn: boolean;
  isAdmin: boolean;
  registerVoter: (voter: Omit<Voter, 'id' | 'registeredAt' | 'hasVoted'>) => boolean;
  loginVoter: (voterId: string, dob: string) => boolean;
  loginAdmin: (username: string, password: string) => boolean;
  logout: () => void;
  castVote: (partyId: string) => boolean;
  getVoterByVoterId: (voterId: string) => Voter | undefined;
  submitFeedback: (feedback: Omit<FeedbackRecord, 'id' | 'submittedAt'>) => void;
}

const VotingContext = createContext<VotingContextType | undefined>(undefined);

export const useVoting = () => {
  const context = useContext(VotingContext);
  if (!context) {
    throw new Error('useVoting must be used within a VotingProvider');
  }
  return context;
};

interface VotingProviderProps {
  children: ReactNode;
}

export const VotingProvider: React.FC<VotingProviderProps> = ({ children }) => {
  const [voters, setVoters] = useState<Voter[]>(() => {
    const saved = localStorage.getItem('voters');
    return saved ? JSON.parse(saved) : [];
  });

  const [votes, setVotes] = useState<VoteRecord[]>(() => {
    const saved = localStorage.getItem('votes');
    return saved ? JSON.parse(saved) : [];
  });

  const [partyVotes, setPartyVotes] = useState<Record<string, number>>(() => {
    const saved = localStorage.getItem('partyVotes');
    if (saved) return JSON.parse(saved);
    const initial: Record<string, number> = {};
    politicalParties.forEach(party => {
      initial[party.id] = 0;
    });
    return initial;
  });

  const [feedbacks, setFeedbacks] = useState<FeedbackRecord[]>(() => {
    const saved = localStorage.getItem('feedbacks');
    return saved ? JSON.parse(saved) : [];
  });

  const [currentVoter, setCurrentVoter] = useState<Voter | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    localStorage.setItem('voters', JSON.stringify(voters));
  }, [voters]);

  useEffect(() => {
    localStorage.setItem('votes', JSON.stringify(votes));
  }, [votes]);

  useEffect(() => {
    localStorage.setItem('partyVotes', JSON.stringify(partyVotes));
  }, [partyVotes]);

  useEffect(() => {
    localStorage.setItem('feedbacks', JSON.stringify(feedbacks));
  }, [feedbacks]);

  const registerVoter = (voterData: Omit<Voter, 'id' | 'registeredAt' | 'hasVoted'>): boolean => {
    const exists = voters.some(v => v.voterId === voterData.voterId || v.email === voterData.email);
    if (exists) return false;

    const newVoter: Voter = {
      ...voterData,
      id: crypto.randomUUID(),
      registeredAt: new Date().toISOString(),
      hasVoted: false,
    };

    setVoters(prev => [...prev, newVoter]);
    return true;
  };

  const loginVoter = (voterId: string, dob: string): boolean => {
    const voter = voters.find(v => v.voterId === voterId && v.dateOfBirth === dob);
    if (voter) {
      setCurrentVoter(voter);
      setIsLoggedIn(true);
      setIsAdmin(false);
      return true;
    }
    return false;
  };

  const loginAdmin = (username: string, password: string): boolean => {
    if (username === 'admin' && password === 'admin123') {
      setIsAdmin(true);
      setIsLoggedIn(true);
      setCurrentVoter(null);
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentVoter(null);
    setIsLoggedIn(false);
    setIsAdmin(false);
  };

  const castVote = (partyId: string): boolean => {
    if (!currentVoter || currentVoter.hasVoted) return false;

    const voteRecord: VoteRecord = {
      voterId: currentVoter.voterId,
      partyId,
      timestamp: new Date().toISOString(),
    };

    setVotes(prev => [...prev, voteRecord]);
    setPartyVotes(prev => ({
      ...prev,
      [partyId]: (prev[partyId] || 0) + 1,
    }));

    setVoters(prev =>
      prev.map(v =>
        v.id === currentVoter.id
          ? { ...v, hasVoted: true, votedParty: partyId, votedAt: new Date().toISOString() }
          : v
      )
    );

    setCurrentVoter(prev =>
      prev ? { ...prev, hasVoted: true, votedParty: partyId, votedAt: new Date().toISOString() } : null
    );

    return true;
  };

  const getVoterByVoterId = (voterId: string): Voter | undefined => {
    return voters.find(v => v.voterId === voterId);
  };

  const submitFeedback = (feedbackData: Omit<FeedbackRecord, 'id' | 'submittedAt'>): void => {
    const newFeedback: FeedbackRecord = {
      ...feedbackData,
      id: crypto.randomUUID(),
      submittedAt: new Date().toISOString(),
    };
    setFeedbacks(prev => [...prev, newFeedback]);
  };

  return (
    <VotingContext.Provider
      value={{
        voters,
        currentVoter,
        votes,
        partyVotes,
        feedbacks,
        isLoggedIn,
        isAdmin,
        registerVoter,
        loginVoter,
        loginAdmin,
        logout,
        castVote,
        getVoterByVoterId,
        submitFeedback,
      }}
    >
      {children}
    </VotingContext.Provider>
  );
};

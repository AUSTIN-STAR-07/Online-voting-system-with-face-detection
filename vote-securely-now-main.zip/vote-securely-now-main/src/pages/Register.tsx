import React, { useState, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useVoting } from '@/context/VotingContext';
import Navbar from '@/components/Navbar';
import { Camera, Upload, User, Mail, CreditCard, Calendar, Users, MapPin, ArrowRight, Check } from 'lucide-react';

const Register: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { registerVoter } = useVoting();
  const photoInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    voterId: '',
    dateOfBirth: '',
    age: '',
    photo: '',
    gender: '' as 'male' | 'female' | 'other' | '',
    addressProof: '',
  });

  const [photoPreview, setPhotoPreview] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const updated = { ...prev, [name]: value };
      
      // Auto-calculate age from DOB
      if (name === 'dateOfBirth' && value) {
        const dob = new Date(value);
        const today = new Date();
        let age = today.getFullYear() - dob.getFullYear();
        const monthDiff = today.getMonth() - dob.getMonth();
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
          age--;
        }
        updated.age = age.toString();
      }
      
      return updated;
    });
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setPhotoPreview(base64);
        setFormData(prev => ({ ...prev, photo: base64 }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Validation
    if (!formData.name || !formData.email || !formData.voterId || !formData.dateOfBirth || !formData.gender || !formData.photo) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      setIsSubmitting(false);
      return;
    }

    if (parseInt(formData.age) < 18) {
      toast({
        title: 'Age Restriction',
        description: 'You must be 18 years or older to register as a voter',
        variant: 'destructive',
      });
      setIsSubmitting(false);
      return;
    }

    const success = registerVoter({
      name: formData.name,
      email: formData.email,
      voterId: formData.voterId,
      dateOfBirth: formData.dateOfBirth,
      age: parseInt(formData.age),
      photo: formData.photo,
      gender: formData.gender as 'male' | 'female' | 'other',
      addressProof: formData.addressProof,
    });

    if (success) {
      toast({
        title: 'Registration Successful!',
        description: 'You can now login to cast your vote.',
      });
      navigate('/login');
    } else {
      toast({
        title: 'Registration Failed',
        description: 'Voter ID or Email already registered',
        variant: 'destructive',
      });
    }
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-full saffron-gradient flex items-center justify-center mx-auto mb-4">
              <User className="w-8 h-8 text-primary-foreground" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">Voter Registration</h1>
            <p className="text-muted-foreground mt-2">Create your account to participate in elections</p>
          </div>

          <form onSubmit={handleSubmit} className="voting-card">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Photo Upload */}
              <div className="md:col-span-2 flex flex-col items-center">
                <Label className="mb-2">Profile Photo *</Label>
                <div 
                  onClick={() => photoInputRef.current?.click()}
                  className="w-32 h-32 rounded-full border-4 border-dashed border-primary/30 flex items-center justify-center cursor-pointer hover:border-primary transition-colors overflow-hidden bg-muted"
                >
                  {photoPreview ? (
                    <img src={photoPreview} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <div className="text-center">
                      <Camera className="w-8 h-8 text-muted-foreground mx-auto mb-1" />
                      <span className="text-xs text-muted-foreground">Upload Photo</span>
                    </div>
                  )}
                </div>
                <input
                  ref={photoInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoChange}
                  className="hidden"
                />
              </div>

              {/* Name */}
              <div className="space-y-2">
                <Label htmlFor="name" className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Full Name *
                </Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="Enter your full name"
                  required
                />
              </div>

              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Email Address *
                </Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="Enter your email"
                  required
                />
              </div>

              {/* Voter ID */}
              <div className="space-y-2">
                <Label htmlFor="voterId" className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  Voter ID Number *
                </Label>
                <Input
                  id="voterId"
                  name="voterId"
                  value={formData.voterId}
                  onChange={handleInputChange}
                  placeholder="e.g., ABC1234567"
                  required
                />
              </div>

              {/* Date of Birth */}
              <div className="space-y-2">
                <Label htmlFor="dateOfBirth" className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Date of Birth *
                </Label>
                <Input
                  id="dateOfBirth"
                  name="dateOfBirth"
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={handleInputChange}
                  required
                />
              </div>

              {/* Age (Auto-calculated) */}
              <div className="space-y-2">
                <Label htmlFor="age">Age</Label>
                <Input
                  id="age"
                  name="age"
                  value={formData.age}
                  readOnly
                  placeholder="Auto-calculated"
                  className="bg-muted"
                />
              </div>

              {/* Gender */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Gender *
                </Label>
                <Select
                  value={formData.gender}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, gender: value as 'male' | 'female' | 'other' }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Address Proof */}
              <div className="md:col-span-2 space-y-2">
                <Label htmlFor="addressProof" className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Address Proof
                </Label>
                <Textarea
                  id="addressProof"
                  name="addressProof"
                  value={formData.addressProof}
                  onChange={handleInputChange}
                  placeholder="Enter your address as per ID proof"
                  rows={3}
                />
              </div>
            </div>

            <div className="mt-8 space-y-4">
              <Button type="submit" className="w-full saffron-gradient gap-2" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>Processing...</>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    Register as Voter
                  </>
                )}
              </Button>

              <p className="text-center text-sm text-muted-foreground">
                Already registered?{' '}
                <Link to="/login" className="text-primary hover:underline font-medium">
                  Login here
                </Link>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Register;

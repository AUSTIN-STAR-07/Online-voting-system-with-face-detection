import React from 'react';
import Navbar from '@/components/Navbar';
import { Shield, Lock, Users, Globe, CheckCircle, Award } from 'lucide-react';

const About: React.FC = () => {
  const features = [
    {
      icon: Shield,
      title: 'Secure Voting',
      description: 'Military-grade encryption ensures your vote remains confidential and tamper-proof.',
    },
    {
      icon: Lock,
      title: 'Identity Protection',
      description: 'Advanced biometric verification prevents unauthorized access and impersonation.',
    },
    {
      icon: Users,
      title: 'Universal Access',
      description: 'Accessible from any device, enabling citizens across India to participate easily.',
    },
    {
      icon: Globe,
      title: 'Transparent Process',
      description: 'Real-time verification and audit trails ensure complete transparency.',
    },
  ];

  const stats = [
    { value: '900M+', label: 'Eligible Voters' },
    { value: '100%', label: 'Secure' },
    { value: '24/7', label: 'Available' },
    { value: '36', label: 'States & UTs' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="py-20 hero-gradient text-secondary-foreground">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              About <span className="text-primary">eVote India</span>
            </h1>
            <p className="text-lg text-secondary-foreground/80">
              eVote India is a next-generation online voting platform designed to make elections 
              more accessible, secure, and transparent for every Indian citizen.
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-primary text-primary-foreground -mt-1">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold mb-1">{stat.value}</div>
                <div className="text-primary-foreground/80 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="voting-card text-center mb-12">
              <div className="w-16 h-16 rounded-full saffron-gradient flex items-center justify-center mx-auto mb-6">
                <Award className="w-8 h-8 text-primary-foreground" />
              </div>
              <h2 className="text-2xl font-bold text-foreground mb-4">Our Mission</h2>
              <p className="text-muted-foreground leading-relaxed">
                To revolutionize India's democratic process by providing a secure, accessible, 
                and transparent digital voting platform that empowers every citizen to participate 
                in shaping the nation's future, regardless of their location or circumstances.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {features.map((feature, index) => (
              <div key={index} className="voting-card">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg saffron-gradient flex items-center justify-center shrink-0">
                    <feature.icon className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground text-sm">{feature.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-foreground mb-12">
            How <span className="text-primary">eVote</span> Works
          </h2>
          <div className="max-w-3xl mx-auto space-y-6">
            {[
              { step: 1, title: 'Register', desc: 'Create your account with valid voter ID and personal details. Upload your photo for biometric verification.' },
              { step: 2, title: 'Verify Identity', desc: 'Login using your Voter ID and Date of Birth. Complete face verification to confirm your identity.' },
              { step: 3, title: 'Cast Your Vote', desc: 'Browse through political parties and select your preferred candidate. Confirm your vote.' },
              { step: 4, title: 'Confirmation', desc: 'Receive instant confirmation that your vote has been securely recorded in the system.' },
            ].map((item) => (
              <div key={item.step} className="flex items-start gap-4 voting-card">
                <div className="w-10 h-10 rounded-full saffron-gradient flex items-center justify-center shrink-0 font-bold text-primary-foreground">
                  {item.step}
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">{item.title}</h3>
                  <p className="text-muted-foreground text-sm">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-secondary text-secondary-foreground">
        <div className="container mx-auto px-4 text-center">
          <p className="text-secondary-foreground/70">
            © 2024 eVote India. A Government of India Initiative for Digital Democracy.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default About;

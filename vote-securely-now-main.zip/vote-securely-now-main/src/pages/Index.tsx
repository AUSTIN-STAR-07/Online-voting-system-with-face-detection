import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import Navbar from '@/components/Navbar';
import { Vote, Shield, Users, CheckCircle, ArrowRight, Fingerprint, Lock } from 'lucide-react';

const Index: React.FC = () => {
  const features = [
    {
      icon: Fingerprint,
      title: 'Biometric Verification',
      description: 'Advanced face recognition ensures only you can cast your vote',
    },
    {
      icon: Shield,
      title: 'Secure & Encrypted',
      description: 'End-to-end encryption protects your vote and personal data',
    },
    {
      icon: Lock,
      title: 'One Vote Policy',
      description: 'Blockchain-inspired technology prevents duplicate voting',
    },
    {
      icon: Users,
      title: 'Accessible to All',
      description: 'Vote from anywhere with our user-friendly interface',
    },
  ];

  const steps = [
    { number: 1, title: 'Register', description: 'Create your voter account with valid ID proof' },
    { number: 2, title: 'Verify Identity', description: 'Complete face verification before voting' },
    { number: 3, title: 'Cast Your Vote', description: 'Select your preferred party securely' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden hero-gradient text-secondary-foreground py-20 lg:py-32">
        <div className="absolute inset-0 pattern-dots opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/20 rounded-full text-primary-foreground mb-6">
              <Vote className="w-4 h-4" />
              <span className="text-sm font-medium">India's Digital Voting Platform</span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Your Vote,{' '}
              <span className="text-primary">Your Voice,</span>
              <br />
              Your Future
            </h1>
            <p className="text-lg md:text-xl text-secondary-foreground/80 mb-8 max-w-2xl mx-auto">
              A secure, transparent, and accessible online voting system enabling every Indian citizen 
              to participate in democracy from anywhere, at any time.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register">
                <Button size="lg" className="saffron-gradient w-full sm:w-auto gap-2 text-lg px-8">
                  Register as Voter
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </Link>
              <Link to="/login">
                <Button size="lg" variant="outline" className="w-full sm:w-auto border-secondary-foreground/30 text-secondary-foreground hover:bg-secondary-foreground/10">
                  Login to Vote
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-primary/20 rounded-full blur-3xl"></div>
        <div className="absolute -top-20 -right-20 w-80 h-80 bg-accent/10 rounded-full blur-3xl"></div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Why Choose <span className="text-primary">eVote India</span>?
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Built with cutting-edge technology to ensure secure, transparent, and accessible elections
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <div key={index} className="voting-card text-center group">
                <div className="w-16 h-16 rounded-2xl saffron-gradient flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <feature.icon className="w-8 h-8 text-primary-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              How It <span className="text-primary">Works</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Three simple steps to cast your vote securely
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                <div className="voting-card text-center h-full">
                  <div className="w-12 h-12 rounded-full saffron-gradient flex items-center justify-center mx-auto mb-4 text-xl font-bold text-primary-foreground">
                    {step.number}
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">{step.title}</h3>
                  <p className="text-muted-foreground text-sm">{step.description}</p>
                </div>
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                    <ArrowRight className="w-8 h-8 text-primary" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 saffron-gradient text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Cast Your Vote?</h2>
          <p className="text-primary-foreground/80 mb-8 max-w-2xl mx-auto">
            Join millions of Indians in shaping the future of our democracy. Register now and make your voice heard.
          </p>
          <Link to="/register">
            <Button size="lg" variant="secondary" className="gap-2 text-lg px-8">
              Get Started
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-secondary text-secondary-foreground py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-lg saffron-gradient flex items-center justify-center">
                <Vote className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">
                e<span className="text-primary">Vote</span> India
              </span>
            </div>
            <p className="text-secondary-foreground/70 text-sm">
              © 2024 eVote India. All rights reserved. A Government of India Initiative.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;

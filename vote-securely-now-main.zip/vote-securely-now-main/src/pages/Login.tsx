import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { useVoting } from '@/context/VotingContext';
import Navbar from '@/components/Navbar';
import { LogIn, CreditCard, Calendar, Shield, User } from 'lucide-react';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { loginVoter, loginAdmin } = useVoting();

  const [voterCredentials, setVoterCredentials] = useState({
    voterId: '',
    dateOfBirth: '',
  });

  const [adminCredentials, setAdminCredentials] = useState({
    username: '',
    password: '',
  });

  const [isLoading, setIsLoading] = useState(false);

  const handleVoterLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const success = loginVoter(voterCredentials.voterId, voterCredentials.dateOfBirth);

    if (success) {
      toast({
        title: 'Login Successful',
        description: 'Welcome back! You can now cast your vote.',
      });
      navigate('/vote');
    } else {
      toast({
        title: 'Login Failed',
        description: 'Invalid Voter ID or Date of Birth',
        variant: 'destructive',
      });
    }
    setIsLoading(false);
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const success = loginAdmin(adminCredentials.username, adminCredentials.password);

    if (success) {
      toast({
        title: 'Admin Login Successful',
        description: 'Welcome to the admin dashboard.',
      });
      navigate('/admin');
    } else {
      toast({
        title: 'Login Failed',
        description: 'Invalid admin credentials',
        variant: 'destructive',
      });
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-full saffron-gradient flex items-center justify-center mx-auto mb-4">
              <LogIn className="w-8 h-8 text-primary-foreground" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">Welcome Back</h1>
            <p className="text-muted-foreground mt-2">Login to access your account</p>
          </div>

          <div className="voting-card">
            <Tabs defaultValue="voter" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="voter" className="gap-2">
                  <User className="w-4 h-4" />
                  Voter
                </TabsTrigger>
                <TabsTrigger value="admin" className="gap-2">
                  <Shield className="w-4 h-4" />
                  Admin
                </TabsTrigger>
              </TabsList>

              <TabsContent value="voter">
                <form onSubmit={handleVoterLogin} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="voterId" className="flex items-center gap-2">
                      <CreditCard className="w-4 h-4" />
                      Voter ID Number
                    </Label>
                    <Input
                      id="voterId"
                      value={voterCredentials.voterId}
                      onChange={(e) => setVoterCredentials(prev => ({ ...prev, voterId: e.target.value }))}
                      placeholder="Enter your Voter ID"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="dob" className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      Date of Birth
                    </Label>
                    <Input
                      id="dob"
                      type="date"
                      value={voterCredentials.dateOfBirth}
                      onChange={(e) => setVoterCredentials(prev => ({ ...prev, dateOfBirth: e.target.value }))}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full saffron-gradient" disabled={isLoading}>
                    {isLoading ? 'Logging in...' : 'Login as Voter'}
                  </Button>

                  <p className="text-center text-sm text-muted-foreground">
                    Don't have an account?{' '}
                    <Link to="/register" className="text-primary hover:underline font-medium">
                      Register here
                    </Link>
                  </p>
                </form>
              </TabsContent>

              <TabsContent value="admin">
                <form onSubmit={handleAdminLogin} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="adminUsername">Username</Label>
                    <Input
                      id="adminUsername"
                      value={adminCredentials.username}
                      onChange={(e) => setAdminCredentials(prev => ({ ...prev, username: e.target.value }))}
                      placeholder="Enter admin username"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="adminPassword">Password</Label>
                    <Input
                      id="adminPassword"
                      type="password"
                      value={adminCredentials.password}
                      onChange={(e) => setAdminCredentials(prev => ({ ...prev, password: e.target.value }))}
                      placeholder="Enter admin password"
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full bg-secondary hover:bg-secondary/90" disabled={isLoading}>
                    {isLoading ? 'Logging in...' : 'Login as Admin'}
                  </Button>

                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground text-center">
                      Demo credentials: <span className="font-medium">admin</span> / <span className="font-medium">admin123</span>
                    </p>
                  </div>
                </form>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;

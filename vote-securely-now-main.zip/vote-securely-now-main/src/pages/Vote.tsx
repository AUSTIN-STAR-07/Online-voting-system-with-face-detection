import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useVoting } from '@/context/VotingContext';
import Navbar from '@/components/Navbar';
import StepIndicator from '@/components/StepIndicator';
import FaceVerification from '@/components/FaceVerification';
import PartySelection from '@/components/PartySelection';
import { AlertCircle, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const Vote: React.FC = () => {
  const navigate = useNavigate();
  const { isLoggedIn, currentVoter } = useVoting();
  const [currentStep, setCurrentStep] = useState(1);
  const [isVerified, setIsVerified] = useState(false);
  const [voteComplete, setVoteComplete] = useState(false);

  const steps = [
    { number: 1, label: 'Identity' },
    { number: 2, label: 'Vote' },
    { number: 3, label: 'Confirm' },
  ];

  useEffect(() => {
    if (!isLoggedIn) {
      navigate('/login');
    }
  }, [isLoggedIn, navigate]);

  if (!isLoggedIn || !currentVoter) {
    return null;
  }

  // Check if user has already voted
  if (currentVoter.hasVoted && !voteComplete) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-lg mx-auto text-center voting-card">
            <div className="w-20 h-20 rounded-full bg-accent flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-accent-foreground" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-2">Already Voted</h2>
            <p className="text-muted-foreground mb-6">
              You have already cast your vote in this election. Each voter can only vote once.
            </p>
            <Link to="/">
              <Button className="saffron-gradient">Return to Home</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const handleVerificationComplete = (success: boolean) => {
    if (success) {
      setIsVerified(true);
      setCurrentStep(2);
    }
  };

  const handleVoteComplete = () => {
    setVoteComplete(true);
    setCurrentStep(3);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <StepIndicator steps={steps} currentStep={currentStep} />

          {currentStep === 1 && (
            <FaceVerification onVerificationComplete={handleVerificationComplete} />
          )}

          {currentStep === 2 && isVerified && (
            <PartySelection onVoteComplete={handleVoteComplete} />
          )}

          {currentStep === 3 && voteComplete && (
            <div className="voting-card max-w-lg mx-auto text-center animate-scale-in">
              <div className="w-20 h-20 rounded-full bg-accent flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-10 h-10 text-accent-foreground" />
              </div>
              <h2 className="text-2xl font-bold text-foreground mb-2">Thank You for Voting!</h2>
              <p className="text-muted-foreground mb-6">
                Your vote has been recorded successfully. Thank you for participating in the democratic process.
              </p>
              <Link to="/">
                <Button className="saffron-gradient">Return to Home</Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Vote;

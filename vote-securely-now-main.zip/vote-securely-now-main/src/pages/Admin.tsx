import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useVoting } from '@/context/VotingContext';
import Navbar from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { getPartyById, politicalParties } from '@/data/politicalParties';
import { 
  Users, 
  Vote, 
  CheckCircle, 
  Clock, 
  Search, 
  BarChart3, 
  User, 
  TrendingUp,
  Shield,
  Activity,
  PieChart,
  FileText,
  Filter,
  Calendar,
  Mail,
  CreditCard,
  UserCheck,
  UserX,
  Trophy,
  MessageSquare,
  Star,
  Building2
} from 'lucide-react';

const Admin: React.FC = () => {
  const navigate = useNavigate();
  const { isLoggedIn, isAdmin, voters, partyVotes, feedbacks } = useVoting();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'voted' | 'pending'>('all');

  useEffect(() => {
    if (!isLoggedIn || !isAdmin) {
      navigate('/login');
    }
  }, [isLoggedIn, isAdmin, navigate]);

  if (!isLoggedIn || !isAdmin) {
    return null;
  }

  const totalVoters = voters.length;
  const votedCount = voters.filter(v => v.hasVoted).length;
  const pendingCount = totalVoters - votedCount;
  const votingPercentage = totalVoters > 0 ? ((votedCount / totalVoters) * 100).toFixed(1) : 0;
  const maleCount = voters.filter(v => v.gender === 'male').length;
  const femaleCount = voters.filter(v => v.gender === 'female').length;
  const otherCount = voters.filter(v => v.gender === 'other').length;

  const filteredVoters = voters.filter(voter => {
    const matchesSearch = 
      voter.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      voter.voterId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      voter.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (statusFilter === 'voted') return matchesSearch && voter.hasVoted;
    if (statusFilter === 'pending') return matchesSearch && !voter.hasVoted;
    return matchesSearch;
  });

  // Sort parties by votes
  const sortedParties = [...politicalParties]
    .map(party => ({ ...party, votes: partyVotes[party.id] || 0 }))
    .sort((a, b) => b.votes - a.votes)
    .filter(party => party.votes > 0);

  const totalVotes = Object.values(partyVotes).reduce((sum, votes) => sum + votes, 0);
  const topParty = sortedParties[0];

  const getRatingStars = (rating: string) => {
    const num = parseInt(rating) || 0;
    return '⭐'.repeat(num);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/30">
      <Navbar />

      <div className="container mx-auto px-4 py-6 lg:py-8">
        {/* Header */}
        <div className="mb-6 lg:mb-8 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl saffron-gradient flex items-center justify-center">
                <Shield className="w-5 h-5 lg:w-6 lg:h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl lg:text-3xl font-bold text-foreground">Admin Dashboard</h1>
                <p className="text-sm text-muted-foreground">Election Management System</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className="px-3 py-1.5 gap-2">
              <Activity className="w-3 h-3 text-accent" />
              <span className="text-accent">Live</span>
            </Badge>
            <Badge variant="secondary" className="px-3 py-1.5 text-xs">
              Last updated: {new Date().toLocaleTimeString()}
            </Badge>
          </div>
        </div>

        {/* Stats Cards - Enhanced Responsive Design */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-8 gap-3 lg:gap-4 mb-6 lg:mb-8">
          {/* Total Registered */}
          <Card className="border-l-4 border-l-primary bg-gradient-to-r from-primary/5 to-transparent col-span-1">
            <CardContent className="p-3 lg:p-4">
              <div className="flex flex-col items-center text-center lg:flex-row lg:text-left lg:justify-between">
                <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-2 lg:mb-0 lg:order-2">
                  <Users className="w-5 h-5 lg:w-6 lg:h-6 text-primary" />
                </div>
                <div className="lg:order-1">
                  <p className="text-[10px] lg:text-xs font-medium text-muted-foreground uppercase tracking-wider">Registered</p>
                  <p className="text-xl lg:text-2xl font-bold text-primary">{totalVoters}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Votes Cast */}
          <Card className="border-l-4 border-l-accent bg-gradient-to-r from-accent/5 to-transparent col-span-1">
            <CardContent className="p-3 lg:p-4">
              <div className="flex flex-col items-center text-center lg:flex-row lg:text-left lg:justify-between">
                <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-2 lg:mb-0 lg:order-2">
                  <CheckCircle className="w-5 h-5 lg:w-6 lg:h-6 text-accent" />
                </div>
                <div className="lg:order-1">
                  <p className="text-[10px] lg:text-xs font-medium text-muted-foreground uppercase tracking-wider">Votes Cast</p>
                  <p className="text-xl lg:text-2xl font-bold text-accent">{votedCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pending */}
          <Card className="border-l-4 border-l-secondary bg-gradient-to-r from-secondary/5 to-transparent col-span-1">
            <CardContent className="p-3 lg:p-4">
              <div className="flex flex-col items-center text-center lg:flex-row lg:text-left lg:justify-between">
                <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-secondary/10 flex items-center justify-center mb-2 lg:mb-0 lg:order-2">
                  <Clock className="w-5 h-5 lg:w-6 lg:h-6 text-secondary" />
                </div>
                <div className="lg:order-1">
                  <p className="text-[10px] lg:text-xs font-medium text-muted-foreground uppercase tracking-wider">Pending</p>
                  <p className="text-xl lg:text-2xl font-bold text-secondary">{pendingCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Turnout Rate */}
          <Card className="border-l-4 border-l-primary bg-gradient-to-r from-primary/5 to-transparent col-span-1">
            <CardContent className="p-3 lg:p-4">
              <div className="flex flex-col items-center text-center lg:flex-row lg:text-left lg:justify-between">
                <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-2 lg:mb-0 lg:order-2">
                  <TrendingUp className="w-5 h-5 lg:w-6 lg:h-6 text-primary" />
                </div>
                <div className="lg:order-1">
                  <p className="text-[10px] lg:text-xs font-medium text-muted-foreground uppercase tracking-wider">Turnout</p>
                  <p className="text-xl lg:text-2xl font-bold text-primary">{votingPercentage}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Leading Party */}
          <Card className="border-l-4 border-l-yellow-500 bg-gradient-to-r from-yellow-500/5 to-transparent col-span-1">
            <CardContent className="p-3 lg:p-4">
              <div className="flex flex-col items-center text-center lg:flex-row lg:text-left lg:justify-between">
                <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-yellow-500/10 flex items-center justify-center mb-2 lg:mb-0 lg:order-2">
                  <Trophy className="w-5 h-5 lg:w-6 lg:h-6 text-yellow-500" />
                </div>
                <div className="lg:order-1">
                  <p className="text-[10px] lg:text-xs font-medium text-muted-foreground uppercase tracking-wider">Leading</p>
                  <p className="text-lg lg:text-xl font-bold text-foreground truncate max-w-[80px]">
                    {topParty?.abbreviation || 'N/A'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Male Voters */}
          <Card className="border-l-4 border-l-blue-500 bg-gradient-to-r from-blue-500/5 to-transparent col-span-1">
            <CardContent className="p-3 lg:p-4">
              <div className="flex flex-col items-center text-center lg:flex-row lg:text-left lg:justify-between">
                <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-blue-500/10 flex items-center justify-center mb-2 lg:mb-0 lg:order-2">
                  <User className="w-5 h-5 lg:w-6 lg:h-6 text-blue-500" />
                </div>
                <div className="lg:order-1">
                  <p className="text-[10px] lg:text-xs font-medium text-muted-foreground uppercase tracking-wider">Male</p>
                  <p className="text-xl lg:text-2xl font-bold text-blue-500">{maleCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Female Voters */}
          <Card className="border-l-4 border-l-pink-500 bg-gradient-to-r from-pink-500/5 to-transparent col-span-1">
            <CardContent className="p-3 lg:p-4">
              <div className="flex flex-col items-center text-center lg:flex-row lg:text-left lg:justify-between">
                <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-pink-500/10 flex items-center justify-center mb-2 lg:mb-0 lg:order-2">
                  <User className="w-5 h-5 lg:w-6 lg:h-6 text-pink-500" />
                </div>
                <div className="lg:order-1">
                  <p className="text-[10px] lg:text-xs font-medium text-muted-foreground uppercase tracking-wider">Female</p>
                  <p className="text-xl lg:text-2xl font-bold text-pink-500">{femaleCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Total Parties */}
          <Card className="border-l-4 border-l-accent bg-gradient-to-r from-accent/5 to-transparent col-span-1">
            <CardContent className="p-3 lg:p-4">
              <div className="flex flex-col items-center text-center lg:flex-row lg:text-left lg:justify-between">
                <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-2 lg:mb-0 lg:order-2">
                  <Building2 className="w-5 h-5 lg:w-6 lg:h-6 text-accent" />
                </div>
                <div className="lg:order-1">
                  <p className="text-[10px] lg:text-xs font-medium text-muted-foreground uppercase tracking-wider">Parties</p>
                  <p className="text-xl lg:text-2xl font-bold text-accent">{politicalParties.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="voters" className="w-full">
          <TabsList className="mb-4 lg:mb-6 bg-muted/50 p-1 flex-wrap h-auto gap-1">
            <TabsTrigger value="voters" className="gap-2 data-[state=active]:saffron-gradient data-[state=active]:text-primary-foreground text-xs lg:text-sm">
              <Users className="w-3 h-3 lg:w-4 lg:h-4" />
              <span className="hidden sm:inline">Registered</span> Voters
            </TabsTrigger>
            <TabsTrigger value="results" className="gap-2 data-[state=active]:saffron-gradient data-[state=active]:text-primary-foreground text-xs lg:text-sm">
              <BarChart3 className="w-3 h-3 lg:w-4 lg:h-4" />
              <span className="hidden sm:inline">Voting</span> Results
            </TabsTrigger>
            <TabsTrigger value="feedback" className="gap-2 data-[state=active]:saffron-gradient data-[state=active]:text-primary-foreground text-xs lg:text-sm">
              <MessageSquare className="w-3 h-3 lg:w-4 lg:h-4" />
              Feedback
              {feedbacks.length > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs px-1.5 py-0">{feedbacks.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="voters">
            <Card>
              <CardHeader className="border-b bg-muted/30 p-4 lg:p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  <CardTitle className="flex items-center gap-2 text-base lg:text-lg">
                    <FileText className="w-4 h-4 lg:w-5 lg:h-5 text-primary" />
                    Voter Registry
                  </CardTitle>
                  <div className="flex flex-col sm:flex-row gap-3">
                    {/* Search */}
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        placeholder="Search voters..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-full sm:w-48 lg:w-64"
                      />
                    </div>
                    {/* Filter */}
                    <div className="flex items-center gap-2">
                      <Filter className="w-4 h-4 text-muted-foreground" />
                      <select 
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value as 'all' | 'voted' | 'pending')}
                        className="bg-background border border-input rounded-md px-3 py-2 text-sm w-full sm:w-auto"
                      >
                        <option value="all">All Voters</option>
                        <option value="voted">Voted</option>
                        <option value="pending">Pending</option>
                      </select>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {/* Table */}
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/50">
                        <TableHead className="font-semibold text-xs lg:text-sm">Photo</TableHead>
                        <TableHead className="font-semibold text-xs lg:text-sm">Voter Details</TableHead>
                        <TableHead className="font-semibold text-xs lg:text-sm hidden md:table-cell">Voter ID</TableHead>
                        <TableHead className="font-semibold text-xs lg:text-sm hidden lg:table-cell">Contact</TableHead>
                        <TableHead className="font-semibold text-xs lg:text-sm hidden sm:table-cell">Age/Gender</TableHead>
                        <TableHead className="font-semibold text-xs lg:text-sm">Status</TableHead>
                        <TableHead className="font-semibold text-xs lg:text-sm hidden sm:table-cell">Voted For</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredVoters.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center py-12">
                            <div className="flex flex-col items-center gap-2">
                              <Users className="w-12 h-12 text-muted-foreground/30" />
                              <p className="text-muted-foreground">No voters found</p>
                              <p className="text-xs text-muted-foreground">Try adjusting your search or filter</p>
                            </div>
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredVoters.map((voter) => {
                          const votedParty = voter.votedParty ? getPartyById(voter.votedParty) : null;
                          return (
                            <TableRow key={voter.id} className="hover:bg-muted/30 transition-colors">
                              <TableCell>
                                <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-full overflow-hidden bg-muted border-2 border-primary/10">
                                  {voter.photo ? (
                                    <img src={voter.photo} alt={voter.name} className="w-full h-full object-cover" />
                                  ) : (
                                    <div className="w-full h-full flex items-center justify-center bg-primary/5">
                                      <User className="w-5 h-5 lg:w-6 lg:h-6 text-muted-foreground" />
                                    </div>
                                  )}
                                </div>
                              </TableCell>
                              <TableCell>
                                <div>
                                  <p className="font-semibold text-foreground text-sm lg:text-base">{voter.name}</p>
                                  <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                                    <Calendar className="w-3 h-3" />
                                    {new Date(voter.dateOfBirth).toLocaleDateString()}
                                  </div>
                                  {/* Mobile-only info */}
                                  <div className="md:hidden text-xs text-muted-foreground mt-1">
                                    <code className="bg-muted px-1 rounded">{voter.voterId}</code>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell className="hidden md:table-cell">
                                <div className="flex items-center gap-2">
                                  <CreditCard className="w-4 h-4 text-muted-foreground" />
                                  <code className="text-xs lg:text-sm bg-muted px-2 py-0.5 rounded">{voter.voterId}</code>
                                </div>
                              </TableCell>
                              <TableCell className="hidden lg:table-cell">
                                <div className="flex items-center gap-1 text-xs lg:text-sm">
                                  <Mail className="w-3 h-3 text-muted-foreground" />
                                  <span className="truncate max-w-[150px]">{voter.email}</span>
                                </div>
                              </TableCell>
                              <TableCell className="hidden sm:table-cell">
                                <div className="flex items-center gap-1 lg:gap-2 flex-wrap">
                                  <Badge variant="outline" className="text-[10px] lg:text-xs">
                                    {voter.age} yrs
                                  </Badge>
                                  <Badge 
                                    variant="secondary" 
                                    className={`text-[10px] lg:text-xs capitalize ${
                                      voter.gender === 'male' ? 'bg-blue-500/10 text-blue-600' : 
                                      voter.gender === 'female' ? 'bg-pink-500/10 text-pink-600' : ''
                                    }`}
                                  >
                                    {voter.gender}
                                  </Badge>
                                </div>
                              </TableCell>
                              <TableCell>
                                {voter.hasVoted ? (
                                  <Badge className="bg-accent/10 text-accent border-accent/20 gap-1 text-[10px] lg:text-xs">
                                    <CheckCircle className="w-3 h-3" />
                                    <span className="hidden sm:inline">Voted</span>
                                  </Badge>
                                ) : (
                                  <Badge variant="secondary" className="bg-muted gap-1 text-[10px] lg:text-xs">
                                    <Clock className="w-3 h-3" />
                                    <span className="hidden sm:inline">Pending</span>
                                  </Badge>
                                )}
                              </TableCell>
                              <TableCell className="hidden sm:table-cell">
                                {votedParty ? (
                                  <div className="flex items-center gap-2">
                                    <div
                                      className="w-6 h-6 lg:w-8 lg:h-8 rounded-lg flex items-center justify-center text-white font-bold text-[10px] lg:text-xs"
                                      style={{ backgroundColor: votedParty.color }}
                                    >
                                      {votedParty.abbreviation.charAt(0)}
                                    </div>
                                    <span className="text-xs lg:text-sm font-medium hidden md:inline">{votedParty.abbreviation}</span>
                                  </div>
                                ) : (
                                  <span className="text-muted-foreground text-sm">—</span>
                                )}
                              </TableCell>
                            </TableRow>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
                {/* Footer */}
                <div className="border-t bg-muted/30 px-4 lg:px-6 py-3 lg:py-4 flex items-center justify-between">
                  <p className="text-xs lg:text-sm text-muted-foreground">
                    Showing {filteredVoters.length} of {totalVoters} voters
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="results">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-6">
              {/* Main Results */}
              <Card className="lg:col-span-2">
                <CardHeader className="border-b bg-muted/30 p-4 lg:p-6">
                  <CardTitle className="flex items-center gap-2 text-base lg:text-lg flex-wrap">
                    <BarChart3 className="w-4 h-4 lg:w-5 lg:h-5 text-primary" />
                    Vote Distribution
                    <Badge variant="secondary" className="ml-2 text-xs">{totalVotes} total votes</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 lg:p-6">
                  {sortedParties.length === 0 ? (
                    <div className="text-center py-12">
                      <Vote className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
                      <p className="text-muted-foreground">No votes cast yet</p>
                      <p className="text-xs text-muted-foreground">Results will appear here once voting begins</p>
                    </div>
                  ) : (
                    <div className="space-y-4 lg:space-y-5">
                      {sortedParties.map((party, index) => {
                        const percentage = totalVotes > 0 ? ((party.votes / totalVotes) * 100).toFixed(1) : 0;
                        const isLeading = index === 0;
                        return (
                          <div key={party.id} className={`relative ${isLeading ? 'scale-[1.02]' : ''}`}>
                            {isLeading && (
                              <div className="absolute -left-1 lg:-left-2 -top-2 z-10">
                                <Badge className="bg-yellow-500 text-white border-0 gap-1 shadow-lg text-[10px] lg:text-xs">
                                  <Trophy className="w-3 h-3" />
                                  Leading
                                </Badge>
                              </div>
                            )}
                            <div className={`p-3 lg:p-4 rounded-xl border ${isLeading ? 'border-yellow-500/50 bg-yellow-500/5' : 'border-border bg-muted/30'}`}>
                              <div className="flex items-center gap-2 lg:gap-4">
                                <span className="w-6 h-6 lg:w-8 lg:h-8 rounded-full bg-muted flex items-center justify-center text-xs lg:text-sm font-bold text-muted-foreground">
                                  #{index + 1}
                                </span>
                                <div
                                  className="w-10 h-10 lg:w-14 lg:h-14 rounded-xl flex items-center justify-center text-white font-bold text-sm lg:text-lg shrink-0 shadow-lg"
                                  style={{ backgroundColor: party.color }}
                                >
                                  {party.abbreviation.substring(0, 2)}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between mb-2">
                                    <div className="min-w-0">
                                      <span className="font-semibold text-foreground block text-xs lg:text-base truncate">{party.name}</span>
                                      <span className="text-[10px] lg:text-xs text-muted-foreground">{party.abbreviation}</span>
                                    </div>
                                    <div className="text-right ml-2">
                                      <span className="text-lg lg:text-2xl font-bold text-foreground">{percentage}%</span>
                                      <span className="text-[10px] lg:text-xs text-muted-foreground block">{party.votes} votes</span>
                                    </div>
                                  </div>
                                  <div className="h-2 lg:h-3 bg-muted rounded-full overflow-hidden">
                                    <div
                                      className="h-full rounded-full transition-all duration-1000 ease-out"
                                      style={{ 
                                        width: `${percentage}%`, 
                                        backgroundColor: party.color 
                                      }}
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Side Stats */}
              <div className="space-y-4 lg:space-y-6">
                <Card>
                  <CardHeader className="pb-3 p-4 lg:p-6 lg:pb-3">
                    <CardTitle className="text-sm lg:text-base flex items-center gap-2">
                      <PieChart className="w-4 h-4 text-primary" />
                      Quick Stats
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 lg:space-y-4 p-4 lg:p-6 pt-0 lg:pt-0">
                    <div className="flex items-center justify-between p-2 lg:p-3 bg-muted/50 rounded-lg">
                      <span className="text-xs lg:text-sm text-muted-foreground">Participation Rate</span>
                      <span className="font-bold text-primary text-sm lg:text-base">{votingPercentage}%</span>
                    </div>
                    <div className="flex items-center justify-between p-2 lg:p-3 bg-muted/50 rounded-lg">
                      <span className="text-xs lg:text-sm text-muted-foreground">Total Candidates</span>
                      <span className="font-bold text-sm lg:text-base">{politicalParties.length}</span>
                    </div>
                    <div className="flex items-center justify-between p-2 lg:p-3 bg-muted/50 rounded-lg">
                      <span className="text-xs lg:text-sm text-muted-foreground">Parties with Votes</span>
                      <span className="font-bold text-sm lg:text-base">{sortedParties.length}</span>
                    </div>
                  </CardContent>
                </Card>

                {topParty && (
                  <Card className="border-yellow-500/50 bg-gradient-to-br from-yellow-500/5 to-transparent">
                    <CardHeader className="pb-3 p-4 lg:p-6 lg:pb-3">
                      <CardTitle className="text-sm lg:text-base flex items-center gap-2">
                        <Trophy className="w-4 h-4 text-yellow-500" />
                        Current Leader
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 lg:p-6 pt-0 lg:pt-0">
                      <div className="text-center">
                        <div
                          className="w-16 h-16 lg:w-20 lg:h-20 rounded-2xl flex items-center justify-center text-white font-bold text-xl lg:text-2xl mx-auto mb-3 shadow-xl"
                          style={{ backgroundColor: topParty.color }}
                        >
                          {topParty.abbreviation.substring(0, 2)}
                        </div>
                        <h3 className="font-bold text-sm lg:text-lg text-foreground">{topParty.name}</h3>
                        <p className="text-xs lg:text-sm text-muted-foreground">{topParty.abbreviation}</p>
                        <div className="mt-3 flex items-center justify-center gap-4">
                          <div>
                            <p className="text-xl lg:text-2xl font-bold text-yellow-500">{topParty.votes}</p>
                            <p className="text-[10px] lg:text-xs text-muted-foreground">Votes</p>
                          </div>
                          <div className="w-px h-8 bg-border"></div>
                          <div>
                            <p className="text-xl lg:text-2xl font-bold text-yellow-500">
                              {totalVotes > 0 ? ((topParty.votes / totalVotes) * 100).toFixed(1) : 0}%
                            </p>
                            <p className="text-[10px] lg:text-xs text-muted-foreground">Share</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Feedback Tab */}
          <TabsContent value="feedback">
            <Card>
              <CardHeader className="border-b bg-muted/30 p-4 lg:p-6">
                <CardTitle className="flex items-center gap-2 text-base lg:text-lg">
                  <MessageSquare className="w-4 h-4 lg:w-5 lg:h-5 text-primary" />
                  User Feedback
                  <Badge variant="secondary" className="ml-2">{feedbacks.length} submissions</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {feedbacks.length === 0 ? (
                  <div className="text-center py-12">
                    <MessageSquare className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
                    <p className="text-muted-foreground">No feedback received yet</p>
                    <p className="text-xs text-muted-foreground">User feedback will appear here</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-muted/50">
                          <TableHead className="font-semibold text-xs lg:text-sm">User</TableHead>
                          <TableHead className="font-semibold text-xs lg:text-sm hidden sm:table-cell">Category</TableHead>
                          <TableHead className="font-semibold text-xs lg:text-sm hidden md:table-cell">Rating</TableHead>
                          <TableHead className="font-semibold text-xs lg:text-sm">Message</TableHead>
                          <TableHead className="font-semibold text-xs lg:text-sm hidden lg:table-cell">Date</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {feedbacks.slice().reverse().map((feedback) => (
                          <TableRow key={feedback.id} className="hover:bg-muted/30 transition-colors">
                            <TableCell>
                              <div>
                                <p className="font-semibold text-foreground text-sm">{feedback.name}</p>
                                <p className="text-xs text-muted-foreground flex items-center gap-1">
                                  <Mail className="w-3 h-3" />
                                  <span className="truncate max-w-[120px]">{feedback.email}</span>
                                </p>
                              </div>
                            </TableCell>
                            <TableCell className="hidden sm:table-cell">
                              <Badge variant="outline" className="capitalize text-xs">
                                {feedback.category}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden md:table-cell">
                              <span className="text-sm">{getRatingStars(feedback.rating) || 'N/A'}</span>
                            </TableCell>
                            <TableCell>
                              <p className="text-sm text-foreground max-w-[200px] lg:max-w-[300px] truncate">
                                {feedback.message}
                              </p>
                            </TableCell>
                            <TableCell className="hidden lg:table-cell">
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Calendar className="w-3 h-3" />
                                {new Date(feedback.submittedAt).toLocaleDateString()}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Admin;